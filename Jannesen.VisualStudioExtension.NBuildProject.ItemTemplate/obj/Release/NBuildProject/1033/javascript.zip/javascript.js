﻿/*eslint strict:0 */
/*global define:false */

define([], function() {
});
